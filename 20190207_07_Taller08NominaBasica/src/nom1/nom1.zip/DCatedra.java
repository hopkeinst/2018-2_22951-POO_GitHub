package nom1;

public class DCatedra extends Docente{
	
	// ATRIBUTOS
	final private static int vHora = 16000;
	private static int horas;
		
	// CONSTRUCTORES
	public DCatedra(String nombre,String id,short edad,String facultad,String ePS,String pension,int horas) {
		super(nombre,id,edad,horas*vHora*4.5,ePS,pension,facultad);
		DCatedra.horas = horas;
	}
		
	// METODOS
	public String toString() {
		return(this.nombre+" => { ID: "+this.id+" | "+this.getEdad()+" años | Tiene "+DCatedra.getHoras()+" horas semanales | Facultad: "+this.facultad+" | EPS: "+this.getePS()+" | Pension: "+this.getPension()+ " }");
	}

	public static int getHoras() {
		return horas;
	}

}
