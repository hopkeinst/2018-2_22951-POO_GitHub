package nom1;

public class Tecnico extends Administrativo{
	
	// ATRIBUTOS
	private static double sueldo = 1200000;
		
	// CONSTRUCTORES
	public Tecnico(String nombre,String id,short edad,String eps,String pension,String dependencia) {
		super(nombre,id,edad,sueldo,dependencia,eps,pension);
	}
		
	// METODOS
	public String toString() {
		return(this.nombre+" => { ID: "+this.id+" | "+this.getEdad()+" años | Dependencia: "+this.getDependencia()+" | EPS: "+this.getePS()+" | Pension: "+this.getPension()+ " }");
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		Tecnico.sueldo = sueldo;
	}

}
