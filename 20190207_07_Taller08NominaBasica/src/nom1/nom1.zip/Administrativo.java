package nom1;

public class Administrativo extends Empleado{

	// ATRIBUTOS
	private String dependencia;
		
	// CONSTRUCTORES
	public Administrativo(String nombre,String id,short edad,double sueldo,String dependencia,String eps,String pension) {
		super(nombre,id,edad,sueldo,eps,pension);
		this.dependencia = dependencia;
	}
		
	// METODOS

	public String getDependencia() {
		return dependencia;
	}

	public void setDependencia(String dependencia) {
		this.dependencia = dependencia;
	}
	
}
