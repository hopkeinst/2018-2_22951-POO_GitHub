package nom1;

public class Auxiliar extends Administrativo{
	
	// ATRIBUTOS
	private static double sueldo = 950000;
		
	// CONSTRUCTORES
	public Auxiliar(String nombre,String id,short edad,String eps,String pension,String dependencia) {
		super(nombre,id,edad,sueldo,dependencia,eps,pension);
	}
		
	// METODOS
	public String toString() {
		return(this.nombre+" => { ID: "+this.id+" | "+this.getEdad()+" años | Dependencia: "+this.getDependencia()+" | EPS: "+this.getePS()+" | Pension: "+this.getPension()+ " }");
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		Auxiliar.sueldo = sueldo;
	}

}
