package nom1;

public class DTiempoCompleto extends Docente{
	
	// ATRIBUTOS
	final static private double sueldo = 3000000;
		
	// CONSTRUCTORES
	public DTiempoCompleto(String nombre,String id,short edad,String ePS,String pension,String facultad) {
		super(nombre,id,edad,sueldo,ePS,pension,facultad);
	}
		
	// METODOS
	public String toString() {
		return(this.nombre+" => { ID: "+this.id+" | "+this.getEdad()+" años | Facultad: "+this.facultad+" | EPS: "+this.getePS()+" | Pension: "+this.getPension()+ " }");
	}

	public double getSueldo() {
		return sueldo;
	}

}
