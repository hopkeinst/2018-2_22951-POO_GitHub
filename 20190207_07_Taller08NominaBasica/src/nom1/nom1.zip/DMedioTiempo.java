package nom1;

public class DMedioTiempo extends Docente{
	
	// ATRIBUTOS
	final static private double sueldo = 1800000;
	private static String jornada;
		
	// CONSTRUCTORES
	public DMedioTiempo(String nombre,String id,short edad,String jornada,String ePS,String pension,String facultad) {
		super(nombre,id,edad,sueldo,ePS,pension,facultad);
		DMedioTiempo.jornada = jornada;
	}
		
	// METODOS
	public String toString() {
		return(this.nombre+" => { ID: "+this.id+" | "+this.getEdad()+" años | Jornada: "+DMedioTiempo.getJornada()+" | Facultad: "+this.facultad+" | EPS: "+this.getePS()+" | Pension: "+this.getPension()+ " }");
	}
	
	public static String getJornada() {
		return jornada;
	}

	public static void setJornada(String jornada) {
		DMedioTiempo.jornada = jornada;
	}

}
