package nom1;

public class Docente extends Empleado{
	
	// ATRIBUTOS
	public String facultad;
		
	// CONSTRUCTORES
	public Docente(String nombre,String id,short edad,double sueldo,String ePS,String pension,String facultad) {
		super(nombre,id,edad,sueldo,ePS,pension);
		this.facultad = facultad;
	}
		
	// METODOS
	public String toString() {
		return(super.toString(this.facultad));
	}

}
