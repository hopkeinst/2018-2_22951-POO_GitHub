package nom1;

public class AOPS extends Administrativo{
	
	// ATRIBUTOS
		
		
	// CONSTRUCTORES
	public AOPS(String nombre,String id,short edad,double sueldo,String eps,String pension,String dependencia) {
		super(nombre,id,edad,sueldo,dependencia,eps,pension);
	}
		
	// METODOS
	public String toString() {
		return(this.nombre+" => { ID: "+this.id+" | "+this.getEdad()+" años | Dependencia: "+this.getDependencia()+" | EPS: "+this.getePS()+" | Pension: "+this.getPension()+ " }");
	}

}
