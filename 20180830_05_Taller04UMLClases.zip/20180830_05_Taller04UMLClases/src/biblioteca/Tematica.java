package biblioteca;

public class Tematica {
	
	public String nombre; //Nombre de la temática
	public int edad; //Por si hay restricción de edad en la temática

// CONTRUCTORES
	
	public Tematica(String nombre, int edad) {
		
	}
	
	public Tematica() {
		
	}
	
// MÉTODOS //
	
	public String listarLibro() {
//Para mostrar los libros de esta temática
		return "0";
	}

}
