package biblioteca;

public class Biblioteca {
	
	public String nombre = "Biblioteca Municiapl";
	public String direccion = "Calle Falsa 123";
	public String telefono = "6123456";
	public int empleados = 10;
	public String fecha = "15/05/2015"; //Fecha inauguración biblioteca

	public Biblioteca() {
//Constructor sin datos ni métodos, porque el objeto se pretende sea único;
// por eso sus atributos son preestablecidos
	}

}
